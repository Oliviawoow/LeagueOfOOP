package main;

public final class Constants {
    //public static final int CEVA = 5;









    private Constants() { }
}
